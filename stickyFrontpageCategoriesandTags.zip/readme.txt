=== Sticky Front Page Categories and Tags ===
Contributors: digitalquill 
Donate link:http://www.digitalquill.co.uk/wordpressplugins/
Tags: categories, tags, frontpage, sticky
Requires at least: 2.8.4
Tested up to: 2.8.6
Stable tag: trunk

Allows you to choose what posts to display on the frontpage of your blog, you can filter these by category(s) or tag(s).

== Description ==

This plugin allows you to choose what posts to display on the front page of your blog. You can select categories and/or tags, posts in those categories or tags will be shown as normal, any others will only be shown if you go into their category.

This is great if you have a blog that is seasonal, and you want to choose which pposts to show on the front page during each season, or if you are using wordpress as a CMS and what to show specific posts on the front page sinply add a tag of frontpage and tellthe plugin to only show those.

== Installation ==

Upload the file via the wordpress install interface or Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
== Screenshots ==
1. The Interface that allows you to choose the tags and categories

== Changelog ==
1.0 - Initial release - 25 Nov 2009